# linguapi-graphql-lambda
Lambda-based GraphQL API for LinguAPI
